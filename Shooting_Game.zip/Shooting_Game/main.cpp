#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#include <windows.h>
#include <glut.h>
#define pi (2*acos(0.0))

double cameraHeight;
double cameraAngle;
int drawgrid;
int drawaxes;
double angle;
double mod;
int triangletx=25,trianglety=-60;
int polygolx=-50,polygoly=40;
int polygon_rx=50,polygon_ry=40;
int rec_lx=-60,rec_ly=-30;
int rec_rx=60,rec_ry=-25;
int circle_ux=10,circle_uy=75;
int circle_lx=-45,circle_ly=-70;
double anglebullet;
bool fire=false,hit=false;
double incx=50, incy;
int state;
double bulletx=0,bullety=0;
struct point
{
    double x,y,z;
};

void push_pop(void)
{
    glPushMatrix();
    //glRotatef(0, 0, 0, 1);
    glPushMatrix(); // Furthest Triangle, Draw first


    //glRotatef(45, 0, 0, 1);
    glTranslatef(-20, 0, 0);
    glScaled(2, 10, 0);
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_POLYGON);
    glVertex2f(10, 10);
    glVertex2f(10, 0);
    glVertex2f(-10, 0);
    glEnd();
    glPopMatrix();

    glPushMatrix(); // Middle Triangle, Draw 2nd
    //glRotatef(90, 0, 0, 1);
    glColor3f(0.0, 1.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(10, 10);
    glVertex2f(10, 0);
    glVertex2f(-10, 0);
    glEnd();
    glPopMatrix();

    glPushMatrix(); // Nearest Triangle, Draw last
    glTranslatef(20, 0, 0);
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(10, 10);
    glVertex2f(10, 0);
    glVertex2f(-10, 0);
    glEnd();
    glPopMatrix();



    glPopMatrix();

}


void drawAxes()
{

    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_LINES);
    {
        glVertex3f( 100,0,0);
        glVertex3f(-100,0,0);

        glVertex3f(0,-100,0);
        glVertex3f(0, 100,0);

        glVertex3f(0,0, 100);
        glVertex3f(0,0,-100);
    }
    glEnd();

}


void drawGrid()
{
    int i;

    glColor3f(0.6, 0.6, 0.6);	//grey
    glBegin(GL_LINES);
    {
        for(i=-8; i<=8; i++)
        {

            if(i==0)
                continue;	//SKIP the MAIN axes

            //lines parallel to Y-axis
            glVertex3f(i*10, -90, 0);
            glVertex3f(i*10,  90, 0);

            //lines parallel to X-axis
            glVertex3f(-90, i*10, 0);
            glVertex3f( 90, i*10, 0);
        }
    }
    glEnd();

}

void drawSquare(double a)
{
    //glColor3f(1.0,0.0,0.0);
    glBegin(GL_QUADS);
    {
        glVertex3f( a, a,2);
        glVertex3f( a,-a,2);
        glVertex3f(-a,-a,2);
        glVertex3f(-a, a,2);
    }
    glEnd();
}


void drawCircle(float radius_x, float radius_y)
{
    int i = 0;
    float angle = 0.0;

    glBegin(GL_POLYGON);
    {
        for(i = 0; i < 100; i++)
        {
            angle = 2 * 3.1416 * i / 100;
            glVertex3f (cos(angle) * radius_x, sin(angle) * radius_y, 0);
        }

    }

    glEnd();
}
void rec_animation()
{
    glColor3f(0,1,0);
    //glRotatef(2*angle,0,0,1);
    glTranslatef(incx,incy,0);
    //glTranslatef(100,0,0);
    glRotatef(5*angle,0,0,1);
    drawSquare(5);

}
void draw_rec()
{
    //glColor3f(0,1,0);

    drawSquare(10);

}
void drawSS()
{
    glPushMatrix();
    glColor3f(1,0,0);
    drawSquare(20);
    //glPushMatrix();
    glRotatef(angle,0,0,1);
    glTranslatef(110,0,0);
    //glRotatef(2*angle,0,0,1);
    glColor3f(0,1,0);
    drawSquare(15);
    //glPopMatrix();

    glRotatef(angle,0,0,1);
    glTranslatef(60,0,0);
    glRotatef(2*angle,0,0,1);
    glColor3f(0,0,1);
    drawSquare(10);
    glPopMatrix();

    glPushMatrix();
    glRotatef(angle,0,0,1);
    glTranslatef(30,0,0);
    //glRotatef(5*angle,0,0,1);
    glColor3f(1,0,1);
    drawSquare(10);
    glPopMatrix();

}

void simple_trans()
{
    //glRotatef(45, 0, 0, 1);
    //glTranslatef(-10, 0, 0);
    //glColor3fglRotatef(0, 0, 0, 1);(0.0, 1.0, 0.0);
    //draw_rec();
    glRotatef(45, 0, 0, 1);
    glTranslatef(-20, 0, 0);
    //glColor3f(1.0, 0.0, 0.0);
    draw_rec();
}

void triangle()
{
    glBegin(GL_POLYGON);
    //glColor3f(0,0,1);
    glVertex2d(0,15);
    glVertex2d(15,-15);
    glVertex2d(-15,-15);
    glEnd();

}


void polygon()
{

    glBegin(GL_POLYGON);
    //glColor3f(0,0,1);
    glVertex2d(0,16);
    glVertex2d(12,10);
    glVertex2d(12,-2);
    glVertex2d(-4,-8);
    glVertex2d(-10,6);
    glEnd();

}


void gun()
{

    glBegin(GL_POLYGON);
    //glColor3f(0,0,1);
    glVertex2d(0,6);
    glVertex2d(2,5);
    glVertex2d(5,2);
    glVertex2d(5,-2);
    glVertex2d(-5,-2);
    glVertex2d(-5,2);
    glVertex2d(-2,5);
    glEnd();

}
void bullet()
{
    glRotated(anglebullet,0,0,1);
    glTranslatef(bulletx,bullety,0);
    drawCircle(3,3);
}
void game()
{

    glPushMatrix();
    bullet();
    glPopMatrix();

    glPushMatrix();


    glPushMatrix();
    glColor3f(1,0,0);
    glRotated(angle,0,0,1);
    glTranslatef(0,0,0);
    glScaled(2,3,0);
    gun();
    glPopMatrix();


    glPushMatrix();
    glColor3f(1,1,0);
    glTranslatef(triangletx,trianglety,0);
    triangle();
    glPopMatrix();




   /* glPushMatrix();
    glColor3f(0,.7,.7);
    glTranslatef(polygon_rx,polygon_ry,0); //righr polygon
    polygon();
    glPopMatrix();*/


    glPushMatrix();
    glColor3f(.7,0,.7);
    glTranslatef(polygolx,polygoly,0); //left polygon
    polygon();
    glPopMatrix();


    glPushMatrix();
    glColor3f(0,0,1);
    glTranslatef(rec_rx,rec_ry,0);//right
    draw_rec();
    /*if(bulletx>60+5 && bullety>-25+5)
    {
        printf("hit/n");

    }*/
    glPopMatrix();


    glPushMatrix();
    glColor3f(1,1,0);
    glTranslatef(rec_lx,rec_ly,0);
    draw_rec();//left
    glPopMatrix();

    glPushMatrix();
    glColor3f(0,1,0);
    glTranslatef(circle_ux,circle_uy,0);//up circle
    drawCircle(15,15);
    glPopMatrix();

   /* glPushMatrix();
    glColor3f(0,1,0);
    glTranslatef(circle_lx,circle_ly,0);//low circle
    drawCircle(15,15);
    glPopMatrix();*/




    glPopMatrix();
}

void keyboardListener(unsigned char key, int xx,int yy)
{
    double x,y,z;
    double rate = 0.01;
    switch(key)
    {

    case 'x':

        fire=true;
        bulletx=0;
        bullety=0;
        anglebullet=angle;
        break;



    default:
        break;
    }

}
void display()
{

    //clear the display
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0,0,0,0);	//color black
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    //load the correct matrix -- MODEL-VIEW matrix
    glMatrixMode(GL_MODELVIEW);

    //initialize the matrix
    glLoadIdentity();

    //now give three info
    //1. where is the camera (viewer)?
    //2. where is the camera looking?
    //3. Which direction is the camera's UP direction?

    //gluLookAt(100,100,100,	0,0,0,	0,0,1);
    //gluLookAt(200*cos(cameraAngle), 200*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
    gluLookAt(0,0,200,	0,0,0,	0,1,0);


    //again select MODEL-VIEW
    glMatrixMode(GL_MODELVIEW);



    //add objects

    drawAxes();
    game();
    //drawGrid();
    //drawCircle(5,5);
    //drawSS();
    //draw_rec();
    //push_pop();
    //simple_trans();
    //rec_animation();
    //drawSquare(20);
    //polygon();







    //ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
    glutSwapBuffers();
}


void animate()
{
    //rotation

    angle+=0.005;
    if (angle>360)
    {
        angle=0;
    }
    if(fire==true)
    {
        bullety+=.005;
    }
    //mod=(anglebullet%360);
    //printf("bulletx : %lf ,bullety : %lf\n",bullety,anglebullet);
    if(bullety>100 || bulletx>100)
    {
        bullety=0;
        fire=false;

    }

    //1
    if(bullety>50 && bullety<60 && anglebullet>33 && anglebullet<44 && hit==false)
    {
        printf("hit\n");
        polygolx=500;
        polygoly=500;
        hit=true;
    }
     hit=false;

    //2

    if(bullety>65 && bullety<100 && anglebullet>68 && anglebullet<132 && hit==false)
    {
        printf("hit\n");
        rec_lx=600;
        rec_ly=600;
        hit=true;
    }
     hit=false;

    //3

    /*if(bullety>100 && bullety<130 && anglebullet>75 && anglebullet<150 && hit==false)
    {
        printf("hit\n");
        circle_lx=500;
        circle_ly=500;
        hit=true;
    }*/
     //hit=false;

    //4
    if(bullety>55 && bullety<60 && anglebullet>191 && anglebullet<212 && hit==false)
    {
        printf("hit\n");
        triangletx=500;
        trianglety=500;
        hit=true;
    }
   // hit=false;


    /*if(bullety>68 && bullety<314 && anglebullet>72 && anglebullet<305 && hit==false)
    {
        printf("hit\n");
        polygon_rx=500;
        polygon_ry=500;
        hit=true;
    }*/
     //hit=false;



    if(bullety>68 && bullety<314 && anglebullet>72 && anglebullet<305 && hit==false)
    {
        printf("hit\n");
        rec_rx=600;
        rec_ry=600;
        hit=true;
    }
    // hit=false;


    //codes for any changes in Models, Camera
    //linear_oscillation


    if(state ==0 && incx>50)
    {
        state =1;
    }
    if(state ==1 && incx <-50)
    {
        state =0;
    }

    if(state == 0) incx+=0.005;
    else incx-=0.005;


    glutPostRedisplay();
}

void init()
{
    //codes for initialization
    drawgrid=0;
    drawaxes=1;
    cameraHeight=150.0;
    cameraAngle=1.0;
    angle=0;

    //clear the screen
    glClearColor(0,0,0,0);


    //load the PROJECTION matrix
    glMatrixMode(GL_PROJECTION);

    //initialize the matrix
    glLoadIdentity();

    //give PERSPECTIVE parameters
    gluPerspective(80,	1,	1,	1000.0);
    //field of view in the Y (vertically)
    //aspect ratio that determines the field of view in the X direction (horizontally)
    //near distance
    //far distance
}

int main(int argc, char **argv)
{
    glutInit(&argc,argv);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

    glutCreateWindow("My OpenGL Program");

    init();

    glEnable(GL_DEPTH_TEST);	//enable Depth Testing

    glutDisplayFunc(display);	//display callback function
    glutIdleFunc(animate);		//what you want to do in the idle time (when no drawing is occuring)
    glutKeyboardFunc(keyboardListener);
    //glutKeyboardFunc(keyboardListener);
    //glutSpecialFunc(specialKeyListener);
    //glutMouseFunc(mouseListener);

    glutMainLoop();		//The main loop of OpenGL

    return 0;
}


